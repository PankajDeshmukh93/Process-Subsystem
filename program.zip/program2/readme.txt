Compiling the file.c  as
Compile : gcc file.c -o filexe


Compiling the Demo.c file as
Complie : gcc Demo.c -o Demoexe
Run     : ./Demoexe hello.txt demo.txt
